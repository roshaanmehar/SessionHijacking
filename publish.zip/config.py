import os
from pathlib import Path
from dotenv import load_dotenv

# Configuration settings
class Config:
    # File paths
    BASE_DIR = Path(__file__).parent
    AUTH_DATA_FILE = BASE_DIR / "auth_data.json"
    LOGS_DIR = BASE_DIR / "logs"
    
    # Framer URLs
    FRAMER_BASE_URL = "https://framer.com"
    FRAMER_LOGIN_URL = "https://framer.com/signin"
    
    # Selenium settings
    IMPLICIT_WAIT = 10
    EXPLICIT_WAIT = 30
    PAGE_LOAD_TIMEOUT = 60
    
    # Stealth settings
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ]
    
    # Timing settings (in seconds)
    MIN_DELAY = 1
    MAX_DELAY = 3
    CLICK_DELAY = 0.5
    
    # Session validation
    SESSION_TIMEOUT_HOURS = 24

    @classmethod
    def load_environment(cls):
        """Load environment variables from .env file"""
        load_dotenv()
    
    @classmethod
    def get_project_url(cls) -> str:
        """Get project URL from environment variable"""
        return os.getenv('FRAMER_PROJECT_URL', '')

    @classmethod
    def get_headless_mode(cls) -> bool:
        """Get headless mode from environment variable"""
        return os.getenv('HEADLESS_MODE', 'false').lower() == 'true'

    @classmethod
    def get_verbose_logging(cls) -> bool:
        """Get verbose logging from environment variable"""
        return os.getenv('VERBOSE_LOGGING', 'false').lower() == 'true'
    
    @classmethod
    def ensure_directories(cls):
        """Create necessary directories if they don't exist"""
        cls.LOGS_DIR.mkdir(exist_ok=True)
