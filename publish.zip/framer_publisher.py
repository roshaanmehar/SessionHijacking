import logging
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from browser_manager import BrowserManager
from auth_manager import AuthManager
from config import Config

class FramerPublisher:
    def __init__(self, project_url: str, headless: bool = False):
        self.project_url = project_url
        self.browser_manager = BrowserManager(headless=headless)
        self.driver = None
        self.auth_manager = None
        self.logger = logging.getLogger(__name__)
        
    def __enter__(self):
        self.driver = self.browser_manager.create_driver()
        self.auth_manager = AuthManager(self.driver)
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.browser_manager.quit()
    
    def login_and_save_session(self) -> bool:
        """Manual login process - user needs to login manually, then we save the session"""
        try:
            self.logger.info("Starting manual login process...")
            
            # Navigate to login page
            self.driver.get(Config.FRAMER_LOGIN_URL)
            self.browser_manager.random_delay(2, 4)
            
            print("\n" + "="*60)
            print("MANUAL LOGIN REQUIRED")
            print("="*60)
            print("1. Please log into Framer in the browser window that just opened")
            print("2. Navigate to your project page")
            print("3. Make sure you can see the 'Publish' button")
            print("4. Press ENTER here when you're ready to save the session")
            print("="*60)
            
            input("Press ENTER when logged in and on your project page...")
            
            # Verify login
            if not self.auth_manager.is_logged_in():
                print("Warning: Could not verify login status. Proceeding anyway...")
            
            # Extract and save auth data
            auth_data = self.auth_manager.extract_auth_data()
            self.auth_manager.save_auth_data(auth_data)
            
            print("✅ Session saved successfully!")
            print("You can now use the automated publishing script.")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error during manual login: {e}")
            return False
    
    def restore_session_and_navigate(self) -> bool:
        """Restore saved session and navigate to project"""
        try:
            # Load auth data
            auth_data = self.auth_manager.load_auth_data()
            if not auth_data:
                self.logger.error("No saved auth data found. Please run login first.")
                return False
            
            # Restore session
            if not self.auth_manager.restore_session(auth_data):
                self.logger.error("Failed to restore session")
                return False
            
            # Navigate to project
            self.logger.info(f"Navigating to project: {self.project_url}")
            self.driver.get(self.project_url)
            self.browser_manager.random_delay(3, 5)
            
            # Verify we're logged in
            if not self.auth_manager.is_logged_in():
                self.logger.error("Session appears to be expired or invalid")
                return False
            
            self.logger.info("Successfully restored session and navigated to project")
            return True
            
        except Exception as e:
            self.logger.error(f"Error restoring session: {e}")
            return False
    
    def publish_project(self) -> bool:
        """Execute the publishing process"""
        try:
            self.logger.info("Starting publishing process...")
            
            # Find and click the main Publish button
            publish_selectors = [
                (By.ID, "toolbar-publish-button"),
                (By.CSS_SELECTOR, "button[aria-label='Publish']"),
                (By.XPATH, "//button[contains(text(), 'Publish')]"),
            ]
            
            publish_button = None
            for selector_type, selector in publish_selectors:
                try:
                    publish_button = WebDriverWait(self.driver, 10).until(
                        EC.element_to_be_clickable((selector_type, selector))
                    )
                    self.logger.info(f"Found publish button using: {selector}")
                    break
                except TimeoutException:
                    continue
            
            if not publish_button:
                self.logger.error("Could not find Publish button")
                return False
            
            # Click publish button
            if not self.browser_manager.safe_click(publish_button):
                self.logger.error("Failed to click Publish button")
                return False
            
            self.logger.info("Clicked Publish button, waiting for menu...")
            self.browser_manager.random_delay(2, 4)
            
            # Find and click the Update button in the popup menu
            update_selectors = [
                (By.CSS_SELECTOR, "button[title='Update']"),
                (By.XPATH, "//button[@title='Update']"),
                (By.XPATH, "//button/span[text()='Update']"),
                (By.XPATH, "//button[contains(text(), 'Update')]"),
            ]
            
            update_button = None
            for selector_type, selector in update_selectors:
                try:
                    update_button = WebDriverWait(self.driver, Config.EXPLICIT_WAIT).until(
                        EC.element_to_be_clickable((selector_type, selector))
                    )
                    self.logger.info(f"Found update button using: {selector}")
                    break
                except TimeoutException:
                    continue
            
            if not update_button:
                self.logger.error("Could not find Update button in popup menu")
                return False
            
            # Click update button
            if not self.browser_manager.safe_click(update_button):
                self.logger.error("Failed to click Update button")
                return False
            
            self.logger.info("Successfully clicked Update button")
            self.browser_manager.random_delay(2, 4)
            
            # Wait for publishing to complete (optional)
            try:
                # Look for success indicators or wait for popup to disappear
                WebDriverWait(self.driver, 30).until(
                    EC.invisibility_of_element_located((By.CSS_SELECTOR, "button[title='Update']"))
                )
                self.logger.info("Publishing appears to be complete")
            except TimeoutException:
                self.logger.warning("Could not confirm publishing completion")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error during publishing: {e}")
            return False
    
    def run_full_automation(self) -> bool:
        """Run the complete automation process"""
        try:
            # Step 1: Restore session and navigate
            if not self.restore_session_and_navigate():
                self.logger.error("Failed to restore session. You may need to login again.")
                return False
            
            # Step 2: Publish project
            if not self.publish_project():
                self.logger.error("Failed to publish project")
                return False
            
            self.logger.info("✅ Automation completed successfully!")
            return True
            
        except Exception as e:
            self.logger.error(f"Error in full automation: {e}")
            return False
